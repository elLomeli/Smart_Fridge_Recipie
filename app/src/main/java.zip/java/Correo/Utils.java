package Correo;

public class Utils {
    // HERE PUT EMAIL AND PASSWORD , LIKE example@gmail.com

    public static final  String EMAIL = "recipiesfree@gmail.com";
    public static final String PASSWORD = "lkpogekprdoxbult";
}
